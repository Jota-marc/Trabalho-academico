        Sistema de Trabalhos Acadêmicos
Um sistema educacional simples com interface gráfica em Tkinter e banco de dados SQLite, que permite o gerenciamento de trabalhos acadêmicos por professores e estudantes. Desenvolvido com Python para fins educacionais e de aprendizado.

 Funcionalidades
  Professores
-Visualizar todos os trabalhos cadastrados

-Editar ou deletar qualquer trabalho

-Gerar relatório completo

-Deletar todos os registros (com reinício de ID)

  Estudantes
-Acessar apenas os trabalhos cadastrados com seu ID

-Adicionar, editar e remover seus próprios trabalhos

-Campos bloqueados para alteração de ID

  Tela de Login
-Escolha entre tipo "Estudante" e "Professor"

-Professores:

Usuário: admin

Senha: admin

-Estudantes:

Usuários: 01 a 05

Senha: igual ao número do usuário (ex: 01 → 01)

